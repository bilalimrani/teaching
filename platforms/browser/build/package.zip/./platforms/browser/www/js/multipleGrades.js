
// let arr = [];
// $(".multipleGrades").click((e)=>{
// 	arr.push(e.target.innerHTML);
// 	$.each(arr, (index, value)=>{
// 		let html = "";
// 		html += `${value}`;
// 		$(".add_teacher_grade").attr('value',html)
// 	})
	
// })