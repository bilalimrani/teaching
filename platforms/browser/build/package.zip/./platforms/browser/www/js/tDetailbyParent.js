
let stdRating_img = document.getElementsByClassName('stdRating_img')[0];
$(document).on('click', '.tDetailbyParent', (e)=>{
	console.log("click",e.target.id)
})